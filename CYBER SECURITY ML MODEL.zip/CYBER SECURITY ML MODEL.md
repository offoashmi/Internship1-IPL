```python
import pandas as pd
df=pd.read_csv("C:\\Users\\Dell\\Desktop\\malicious_phish.csv")
df.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
    </tr>
    <tr>
      <th>5</th>
      <td>http://buzzfil.net/m/show-art/ils-etaient-loin...</td>
      <td>benign</td>
    </tr>
    <tr>
      <th>6</th>
      <td>espn.go.com/nba/player/_/id/3457/brandon-rush</td>
      <td>benign</td>
    </tr>
    <tr>
      <th>7</th>
      <td>yourbittorrent.com/?q=anthony-hamilton-soulife</td>
      <td>benign</td>
    </tr>
    <tr>
      <th>8</th>
      <td>http://www.pashminaonline.com/pure-pashminas</td>
      <td>defacement</td>
    </tr>
    <tr>
      <th>9</th>
      <td>allmusic.com/album/crazy-from-the-heat-r16990</td>
      <td>benign</td>
    </tr>
  </tbody>
</table>
</div>



types of URLs

Benign URLs: 
These are safe to browse URLs. 

Malware URLs: 
These type of URLs inject malware into the victim’s system once he/she visit such URLs. 

Defacement URLs: 
Defacement URLs are generally created by hackers with the intention of breaking into a web server and replacing the hosted website with one of their own, using techniques such as code injection, cross-site scripting, etc. Common targets of defacement URLs are religious websites, government websites, bank websites, and corporate websites. 

Phishing URLs:
By creating phishing URLs, hackers try to steal sensitive personal or financial information such as login credentials, credit card numbers, internet banking details, etc. 

WORDCLOUD OF URLs
* technique of NLP
word cloud of benign URLs is pretty obvious having frequent tokens such as html, com, org, wiki etc. 
Phishing URLs have frequent tokens as tools, ietf, www, index, battle, net whereas html, org, html are higher frequency tokens as these URLs try to mimick original URLs for deceiving the users.
The word cloud of malware URLs has higher frequency tokens of exe, E7, BB, MOZI. These tokens are also obvious as malware URLs try to install trojans in the form of executable files over the users’ system once the user visits those URLs.

The defacement URLs’ intention is to modify the original website’s code and this is the reason that tokens in its word cloud are more common development terms such as index, php, itemid, https, option, etc.


```python
# importing necessary libraries
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
from sklearn.model_selection import train_test_split
import xgboost as xgb
from lightgbm import LGBMClassifier
from wordcloud import WordCloud
import itertools
from sklearn.metrics import classification_report,confusion_matrix, accuracy_score

```

    C:\Users\Dell\anaconda3\lib\site-packages\dask\dataframe\_pyarrow_compat.py:23: UserWarning: You are using pyarrow version 13.0.0 which is known to be insecure. See https://www.cve.org/CVERecord?id=CVE-2023-47248 for further details. Please upgrade to pyarrow>=14.0.1 or install pyarrow-hotfix to patch your current version.
      warnings.warn(
    


```python
pip install xgboost
```

    Requirement already satisfied: xgboost in c:\users\dell\appdata\roaming\python\python39\site-packages (2.0.2)
    Requirement already satisfied: numpy in c:\users\dell\anaconda3\lib\site-packages (from xgboost) (1.24.4)
    Requirement already satisfied: scipy in c:\users\dell\anaconda3\lib\site-packages (from xgboost) (1.9.1)
    Note: you may need to restart the kernel to use updated packages.
    


```python
# importing necessary libraries
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
from sklearn.model_selection import train_test_split
import xgboost as xgb
from lightgbm import LGBMClassifier
from wordcloud import WordCloud
import itertools
from sklearn.metrics import classification_report,confusion_matrix, accuracy_score

```


```python
pip install xgboost --user

```

    Requirement already satisfied: xgboost in c:\users\dell\appdata\roaming\python\python39\site-packages (2.0.2)
    Requirement already satisfied: numpy in c:\users\dell\anaconda3\lib\site-packages (from xgboost) (1.24.4)
    Requirement already satisfied: scipy in c:\users\dell\anaconda3\lib\site-packages (from xgboost) (1.9.1)
    Note: you may need to restart the kernel to use updated packages.
    


```python
# importing necessary libraries
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
from sklearn.model_selection import train_test_split
import xgboost as xgb
from lightgbm import LGBMClassifier
from wordcloud import WordCloud
import itertools
from sklearn.metrics import classification_report,confusion_matrix, accuracy_score

```


```python
pip install lightgbm --user
```

    Requirement already satisfied: lightgbm in c:\users\dell\appdata\roaming\python\python39\site-packages (4.1.0)
    Requirement already satisfied: numpy in c:\users\dell\anaconda3\lib\site-packages (from lightgbm) (1.24.4)
    Requirement already satisfied: scipy in c:\users\dell\anaconda3\lib\site-packages (from lightgbm) (1.9.1)
    Note: you may need to restart the kernel to use updated packages.
    


```python
# importing necessary libraries
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
from sklearn.model_selection import train_test_split
import xgboost as xgb
from lightgbm import LGBMClassifier
from wordcloud import WordCloud
import itertools
from sklearn.metrics import classification_report,confusion_matrix, accuracy_score
```


```python
from lightgbm import LGBMClassifier
```


```python
from wordcloud import WordCloud
```


```python
import wordcloud

```


```python
from wordcloud import WordCloud
```


```python
import itertools
```


```python
from sklearn.metrics import classification_report,confusion_matrix, accuracy_score
```


```python
# importing necessary libraries
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
from sklearn.model_selection import train_test_split
import xgboost as xgb
from lightgbm import LGBMClassifier
from wordcloud import WordCloud
import itertools
from sklearn.metrics import classification_report,confusion_matrix, accuracy_score
```

FEATURE ENGINEERING
 
there are several ways to distinguish a malicious URL from a benign one
 
has_ip_address--Generally cyber attackers use an IP address in place of the domain name to hide the identity of the website
abnormal_url--For a legitimate website, identity is typically part of its URL.
google_index--Google indexes web pages to make them searchable for users when they perform a search,this feature checks that

Count . -- The phishing or malware websites generally use more than two sub-domains in the URL. Each domain is separated by dot (.). If any URL contains more than three dots(.), then it increases the probability of a malicious site.
 
Count-www--Generally most of the safe websites have one www in its URL. This feature helps in detecting malicious websites if the URL has no or more than one www in its URL.

count@--The presence of the “@” symbol in the URL ignores everything previous to it.
 
Count_dir-- The presence of multiple directories in the URL generally indicates suspicious websites.

Count_embed_domain--The number of the embedded domains can be helpful in detecting malicious URLs. It can be done by checking the occurrence of “//” in the URL.

Suspicious words in URL-- Malicious URLs generally contain suspicious words in the URL 

Short_url--This feature is created to identify whether the URL uses URL shortening services like bit. \ly, goo.gl, go2l.ink

Count_https--Generally malicious URLs do not use HTTPS protocols as it generally requires user credentials and ensures that the website is safe for transactions. So, the presence or absence of HTTPS protocol in the URL is an important feature.

Count%-- As we know URLs cannot contain spaces. URL encoding normally replaces spaces with symbol (%). Safe sites generally contain less number of spaces whereas malicious websites generally contain more spaces in their URL hence more number of %.

Count?--- This symbol(?) in URL denotes a query string that contains the data to be passed to the server. More number of ? in URL definitely indicates suspicious URL.

Count- -- Phishers or cybercriminals generally add dashes(-) in prefix or suffix of the brand name so that it looks genuine URL. For example. 

Count= -- Presence of (=) in URL indicates passing of variable values from one form page to another. It is considered as riskier in URL as anyone can change the values to modify the page.

url_length -- Attackers generally use long URLs to hide the domain name. 
(safe URL length = 74)

hostname_length -- hostname length is also important for detecting malicious URLs.

First directory length -- length of the first directory in the URL. So looking for the first ‘/’ and counting the length of the URL till this is first directory length.

Length of top-level domain--  length of TLD is also important in identifying malicious URLs. TLDs in the range from 2 to 3 generally indicate safe URLs.

Count_digits-- Safe URLs generally do not have digits 

Count_letters--attackers try to increase the length of the URL to hide the domain name by increasing the number of letters and digits in the URL.


```python
df=pd.read_csv("C:\\Users\\Dell\\Desktop\\malicious_phish.csv")
df.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
    </tr>
    <tr>
      <th>5</th>
      <td>http://buzzfil.net/m/show-art/ils-etaient-loin...</td>
      <td>benign</td>
    </tr>
    <tr>
      <th>6</th>
      <td>espn.go.com/nba/player/_/id/3457/brandon-rush</td>
      <td>benign</td>
    </tr>
    <tr>
      <th>7</th>
      <td>yourbittorrent.com/?q=anthony-hamilton-soulife</td>
      <td>benign</td>
    </tr>
    <tr>
      <th>8</th>
      <td>http://www.pashminaonline.com/pure-pashminas</td>
      <td>defacement</td>
    </tr>
    <tr>
      <th>9</th>
      <td>allmusic.com/album/crazy-from-the-heat-r16990</td>
      <td>benign</td>
    </tr>
  </tbody>
</table>
</div>




```python
# we'll use a module in python named re, it helps us scan through a string for a match to given input 
import re
# have_ip_adress--- 1
def having_ip_address(url):
    # Regular expression for matching IPv4 addresses
    ip_pattern = r'\b(?:\d{1,3}\.){3}\d{1,3}\b'
    match = re.search(ip_pattern, url)
    if bool(match)==True:
        return 1
    else:
        return 0
#applying function to each element in the df
df["has_ip"]=df["url"].apply(lambda i:having_ip_address(i))
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>651186</th>
      <td>xbox360.ign.com/objects/850/850402.html</td>
      <td>phishing</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651187</th>
      <td>games.teamxbox.com/xbox-360/1860/Dead-Space/</td>
      <td>phishing</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651188</th>
      <td>www.gamespot.com/xbox360/action/deadspace/</td>
      <td>phishing</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651189</th>
      <td>en.wikipedia.org/wiki/Dead_Space_(video_game)</td>
      <td>phishing</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651190</th>
      <td>www.angelfire.com/goth/devilmaycrytonite/</td>
      <td>phishing</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>651191 rows × 3 columns</p>
</div>




```python
from urllib.parse import urlparse
def abnormal_url(url):
    hostname = urlparse(url).hostname
    hostname = str(hostname)
    match = re.search(hostname, url)
    if match:
        return 1
    else:
        return 0
df['abnormal_url'] = df['url'].apply(lambda i: abnormal_url(i))
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
      <th>abnormal_url</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>651186</th>
      <td>xbox360.ign.com/objects/850/850402.html</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651187</th>
      <td>games.teamxbox.com/xbox-360/1860/Dead-Space/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651188</th>
      <td>www.gamespot.com/xbox360/action/deadspace/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651189</th>
      <td>en.wikipedia.org/wiki/Dead_Space_(video_game)</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651190</th>
      <td>www.angelfire.com/goth/devilmaycrytonite/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>651191 rows × 4 columns</p>
</div>




```python
pip install googlesearch-python
```

    Requirement already satisfied: googlesearch-python in c:\users\dell\anaconda3\lib\site-packages (1.2.3)
    Requirement already satisfied: beautifulsoup4>=4.9 in c:\users\dell\anaconda3\lib\site-packages (from googlesearch-python) (4.11.1)
    Requirement already satisfied: requests>=2.20 in c:\users\dell\anaconda3\lib\site-packages (from googlesearch-python) (2.28.1)
    Requirement already satisfied: soupsieve>1.2 in c:\users\dell\anaconda3\lib\site-packages (from beautifulsoup4>=4.9->googlesearch-python) (2.3.1)
    Requirement already satisfied: idna<4,>=2.5 in c:\users\dell\anaconda3\lib\site-packages (from requests>=2.20->googlesearch-python) (3.3)
    Requirement already satisfied: urllib3<1.27,>=1.21.1 in c:\users\dell\anaconda3\lib\site-packages (from requests>=2.20->googlesearch-python) (1.26.11)
    Requirement already satisfied: charset-normalizer<3,>=2 in c:\users\dell\anaconda3\lib\site-packages (from requests>=2.20->googlesearch-python) (2.0.4)
    Requirement already satisfied: certifi>=2017.4.17 in c:\users\dell\anaconda3\lib\site-packages (from requests>=2.20->googlesearch-python) (2022.9.14)
    Note: you may need to restart the kernel to use updated packages.
    


```python
from googlesearch import search
# performs search in google
```


```python
# function to determine wether a url in indexed by google or not
def google_index(url):
    res = search(url, 10)# returns top 10 searches
    if res:
        return 1
    else:
        return 0
df['google_index'] = df['url'].apply(lambda i: google_index(i))
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>google_index</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>651186</th>
      <td>xbox360.ign.com/objects/850/850402.html</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>651187</th>
      <td>games.teamxbox.com/xbox-360/1860/Dead-Space/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>651188</th>
      <td>www.gamespot.com/xbox360/action/deadspace/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>651189</th>
      <td>en.wikipedia.org/wiki/Dead_Space_(video_game)</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>651190</th>
      <td>www.angelfire.com/goth/devilmaycrytonite/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>651191 rows × 5 columns</p>
</div>




```python
# counting number of .(>3-malicious)
def cdot(url):
    cdot = url.count('.')
    return cdot
df['count_dot'] = df['url'].apply(lambda i: cdot(i))
column_to_drop = 'count.'
df = df.drop(column_to_drop, axis=1)
df
```


    ---------------------------------------------------------------------------

    KeyError                                  Traceback (most recent call last)

    ~\AppData\Local\Temp\ipykernel_22668\540870597.py in <module>
          5 df['count_dot'] = df['url'].apply(lambda i: cdot(i))
          6 column_to_drop = 'count.'
    ----> 7 df = df.drop(column_to_drop, axis=1)
          8 df
    

    ~\anaconda3\lib\site-packages\pandas\core\frame.py in drop(self, labels, axis, index, columns, level, inplace, errors)
       5342                 weight  1.0     0.8
       5343         """
    -> 5344         return super().drop(
       5345             labels=labels,
       5346             axis=axis,
    

    ~\anaconda3\lib\site-packages\pandas\core\generic.py in drop(self, labels, axis, index, columns, level, inplace, errors)
       4709         for axis, labels in axes.items():
       4710             if labels is not None:
    -> 4711                 obj = obj._drop_axis(labels, axis, level=level, errors=errors)
       4712 
       4713         if inplace:
    

    ~\anaconda3\lib\site-packages\pandas\core\generic.py in _drop_axis(self, labels, axis, level, errors, only_slice)
       4751                 new_axis = axis.drop(labels, level=level, errors=errors)
       4752             else:
    -> 4753                 new_axis = axis.drop(labels, errors=errors)
       4754             indexer = axis.get_indexer(new_axis)
       4755 
    

    ~\anaconda3\lib\site-packages\pandas\core\indexes\base.py in drop(self, labels, errors)
       6990         if mask.any():
       6991             if errors != "ignore":
    -> 6992                 raise KeyError(f"{labels[mask].tolist()} not found in axis")
       6993             indexer = indexer[~mask]
       6994         return self.delete(indexer)
    

    KeyError: "['count.'] not found in axis"



```python
def www(url):
    c=url.count('www')
    return c
df['count_www'] = df['url'].apply(lambda i: www(i))
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>google_index</th>
      <th>count-www</th>
      <th>count@</th>
      <th>count_dir</th>
      <th>count_embedded_dom</th>
      <th>is_short</th>
      <th>...</th>
      <th>hostname_length</th>
      <th>sus_url</th>
      <th>count-digits</th>
      <th>count-letters</th>
      <th>fd_length</th>
      <th>tld</th>
      <th>tld_length</th>
      <th>type_code</th>
      <th>count_dot</th>
      <th>count_www</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>13</td>
      <td>0</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>29</td>
      <td>5</td>
      <td>None</td>
      <td>-1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>25</td>
      <td>7</td>
      <td>None</td>
      <td>-1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>21</td>
      <td>0</td>
      <td>7</td>
      <td>63</td>
      <td>9</td>
      <td>be</td>
      <td>2</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>23</td>
      <td>0</td>
      <td>22</td>
      <td>199</td>
      <td>9</td>
      <td>net</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>651186</th>
      <td>xbox360.ign.com/objects/850/850402.html</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>12</td>
      <td>21</td>
      <td>7</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651187</th>
      <td>games.teamxbox.com/xbox-360/1860/Dead-Space/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>7</td>
      <td>29</td>
      <td>8</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651188</th>
      <td>www.gamespot.com/xbox360/action/deadspace/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>33</td>
      <td>7</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>651189</th>
      <td>en.wikipedia.org/wiki/Dead_Space_(video_game)</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>36</td>
      <td>4</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651190</th>
      <td>www.angelfire.com/goth/devilmaycrytonite/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>36</td>
      <td>4</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>651191 rows × 26 columns</p>
</div>




```python
def cat(url):
    c=url.count('@')
    return c
df['count_atrate'] = df['url'].apply(lambda i: cat(i))
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>google_index</th>
      <th>count-www</th>
      <th>count@</th>
      <th>count_dir</th>
      <th>count_embedded_dom</th>
      <th>is_short</th>
      <th>...</th>
      <th>sus_url</th>
      <th>count-digits</th>
      <th>count-letters</th>
      <th>fd_length</th>
      <th>tld</th>
      <th>tld_length</th>
      <th>type_code</th>
      <th>count_dot</th>
      <th>count_www</th>
      <th>count_atrate</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>13</td>
      <td>0</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>29</td>
      <td>5</td>
      <td>None</td>
      <td>-1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>25</td>
      <td>7</td>
      <td>None</td>
      <td>-1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>7</td>
      <td>63</td>
      <td>9</td>
      <td>be</td>
      <td>2</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>22</td>
      <td>199</td>
      <td>9</td>
      <td>net</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>651186</th>
      <td>xbox360.ign.com/objects/850/850402.html</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>12</td>
      <td>21</td>
      <td>7</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651187</th>
      <td>games.teamxbox.com/xbox-360/1860/Dead-Space/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>7</td>
      <td>29</td>
      <td>8</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651188</th>
      <td>www.gamespot.com/xbox360/action/deadspace/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>3</td>
      <td>33</td>
      <td>7</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651189</th>
      <td>en.wikipedia.org/wiki/Dead_Space_(video_game)</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>36</td>
      <td>4</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651190</th>
      <td>www.angelfire.com/goth/devilmaycrytonite/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>36</td>
      <td>4</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>651191 rows × 27 columns</p>
</div>




```python
def ndir(url):
    ndir = urlparse(url).path# exptracts the path from the url it parses through
    return ndir.count('/')# counts the number of / in the path---multiple /--multiple directories--malicious url
df['count_dir'] = df['url'].apply(lambda i: ndir(i))
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>google_index</th>
      <th>count.</th>
      <th>count-www</th>
      <th>count@</th>
      <th>count_dir</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>651186</th>
      <td>xbox360.ign.com/objects/850/850402.html</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>651187</th>
      <td>games.teamxbox.com/xbox-360/1860/Dead-Space/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
    </tr>
    <tr>
      <th>651188</th>
      <td>www.gamespot.com/xbox360/action/deadspace/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
    </tr>
    <tr>
      <th>651189</th>
      <td>en.wikipedia.org/wiki/Dead_Space_(video_game)</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>651190</th>
      <td>www.angelfire.com/goth/devilmaycrytonite/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
    </tr>
  </tbody>
</table>
<p>651191 rows × 9 columns</p>
</div>




```python
def ndom(url):
    ndom = urlparse(url).path
    return ndom.count('//')
df['count_embedded_dom'] = df['url'].apply(lambda i: ndom(i))
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>google_index</th>
      <th>count.</th>
      <th>count-www</th>
      <th>count@</th>
      <th>count_dir</th>
      <th>count_embedded_dom</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>651186</th>
      <td>xbox360.ign.com/objects/850/850402.html</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651187</th>
      <td>games.teamxbox.com/xbox-360/1860/Dead-Space/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651188</th>
      <td>www.gamespot.com/xbox360/action/deadspace/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651189</th>
      <td>en.wikipedia.org/wiki/Dead_Space_(video_game)</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651190</th>
      <td>www.angelfire.com/goth/devilmaycrytonite/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>651191 rows × 10 columns</p>
</div>




```python
# function to check if a url uses shortening services eg. bitly etc
def shorturl(url):
    cw = ['bit.ly','goo.gl','t.co']
    if urlparse(url).netloc in cw:
        return 1
    else:
        return 0
    
df['is_short'] = df['url'].apply(lambda i: shorturl(i))
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>google_index</th>
      <th>count.</th>
      <th>count-www</th>
      <th>count@</th>
      <th>count_dir</th>
      <th>count_embedded_dom</th>
      <th>is_short</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>651186</th>
      <td>xbox360.ign.com/objects/850/850402.html</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651187</th>
      <td>games.teamxbox.com/xbox-360/1860/Dead-Space/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651188</th>
      <td>www.gamespot.com/xbox360/action/deadspace/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651189</th>
      <td>en.wikipedia.org/wiki/Dead_Space_(video_game)</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651190</th>
      <td>www.angelfire.com/goth/devilmaycrytonite/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>651191 rows × 11 columns</p>
</div>




```python
df1=df[df['is_short']==1]
df1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>google_index</th>
      <th>count.</th>
      <th>count-www</th>
      <th>count@</th>
      <th>count_dir</th>
      <th>count_embedded_dom</th>
      <th>is_short</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>93007</th>
      <td>http://bit.ly/R1Y0kU?2000.Ford.F250.Lariat/130...</td>
      <td>phishing</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>128002</th>
      <td>http://bit.ly/M77GIA?ferias=93840923804983</td>
      <td>phishing</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>448721</th>
      <td>http://bit.ly/X0QmNx?2007.Subaru.Impreza.WRX/1...</td>
      <td>phishing</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>520404</th>
      <td>https://bit.ly/contentfrb</td>
      <td>phishing</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>521371</th>
      <td>http://bit.ly/meu-itanet1</td>
      <td>phishing</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>532506</th>
      <td>https://t.co/ZrrTHUwKDS?amp=1</td>
      <td>phishing</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>532607</th>
      <td>https://t.co/dXsbg4zamu?amp=1</td>
      <td>phishing</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>532643</th>
      <td>https://t.co/dXsbg4zamu</td>
      <td>phishing</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>532855</th>
      <td>http://bit.ly/312TfkD</td>
      <td>phishing</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>534411</th>
      <td>http://t.co/ZXCtb9xgsu</td>
      <td>phishing</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>84 rows × 11 columns</p>
</div>




```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>google_index</th>
      <th>count.</th>
      <th>count-www</th>
      <th>count@</th>
      <th>count_dir</th>
      <th>count_embedded_dom</th>
      <th>is_short</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>651186</th>
      <td>xbox360.ign.com/objects/850/850402.html</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651187</th>
      <td>games.teamxbox.com/xbox-360/1860/Dead-Space/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651188</th>
      <td>www.gamespot.com/xbox360/action/deadspace/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651189</th>
      <td>en.wikipedia.org/wiki/Dead_Space_(video_game)</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651190</th>
      <td>www.angelfire.com/goth/devilmaycrytonite/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>651191 rows × 11 columns</p>
</div>




```python
def https(url):
    c=url.count('https')
    return c
df['count_https'] = df['url'].apply(lambda i : https(i))
df
#df1=df[df['count_https']==1]
#df1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>google_index</th>
      <th>count-www</th>
      <th>count@</th>
      <th>count_dir</th>
      <th>count_embedded_dom</th>
      <th>is_short</th>
      <th>...</th>
      <th>count-digits</th>
      <th>count-letters</th>
      <th>fd_length</th>
      <th>tld</th>
      <th>tld_length</th>
      <th>type_code</th>
      <th>count_dot</th>
      <th>count_www</th>
      <th>count_atrate</th>
      <th>count_https</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>13</td>
      <td>0</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>29</td>
      <td>5</td>
      <td>None</td>
      <td>-1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>25</td>
      <td>7</td>
      <td>None</td>
      <td>-1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>7</td>
      <td>63</td>
      <td>9</td>
      <td>be</td>
      <td>2</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>22</td>
      <td>199</td>
      <td>9</td>
      <td>net</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>651186</th>
      <td>xbox360.ign.com/objects/850/850402.html</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>12</td>
      <td>21</td>
      <td>7</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651187</th>
      <td>games.teamxbox.com/xbox-360/1860/Dead-Space/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>7</td>
      <td>29</td>
      <td>8</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651188</th>
      <td>www.gamespot.com/xbox360/action/deadspace/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3</td>
      <td>33</td>
      <td>7</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651189</th>
      <td>en.wikipedia.org/wiki/Dead_Space_(video_game)</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>36</td>
      <td>4</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651190</th>
      <td>www.angelfire.com/goth/devilmaycrytonite/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>36</td>
      <td>4</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>651191 rows × 28 columns</p>
</div>




```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>google_index</th>
      <th>count.</th>
      <th>count-www</th>
      <th>count@</th>
      <th>count_dir</th>
      <th>count_embedded_dom</th>
      <th>is_short</th>
      <th>count-https</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>651186</th>
      <td>xbox360.ign.com/objects/850/850402.html</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651187</th>
      <td>games.teamxbox.com/xbox-360/1860/Dead-Space/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651188</th>
      <td>www.gamespot.com/xbox360/action/deadspace/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651189</th>
      <td>en.wikipedia.org/wiki/Dead_Space_(video_game)</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651190</th>
      <td>www.angelfire.com/goth/devilmaycrytonite/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>651191 rows × 12 columns</p>
</div>




```python
def per(url):
    c=url.count('%')
    return c
df['count_per'] = df['url'].apply(lambda i : per(i))
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>google_index</th>
      <th>count-www</th>
      <th>count@</th>
      <th>count_dir</th>
      <th>count_embedded_dom</th>
      <th>is_short</th>
      <th>...</th>
      <th>count-letters</th>
      <th>fd_length</th>
      <th>tld</th>
      <th>tld_length</th>
      <th>type_code</th>
      <th>count_dot</th>
      <th>count_www</th>
      <th>count_atrate</th>
      <th>count_https</th>
      <th>count_per</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>13</td>
      <td>0</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>29</td>
      <td>5</td>
      <td>None</td>
      <td>-1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>25</td>
      <td>7</td>
      <td>None</td>
      <td>-1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>63</td>
      <td>9</td>
      <td>be</td>
      <td>2</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>199</td>
      <td>9</td>
      <td>net</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>651186</th>
      <td>xbox360.ign.com/objects/850/850402.html</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>21</td>
      <td>7</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651187</th>
      <td>games.teamxbox.com/xbox-360/1860/Dead-Space/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>29</td>
      <td>8</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651188</th>
      <td>www.gamespot.com/xbox360/action/deadspace/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>33</td>
      <td>7</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651189</th>
      <td>en.wikipedia.org/wiki/Dead_Space_(video_game)</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>36</td>
      <td>4</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651190</th>
      <td>www.angelfire.com/goth/devilmaycrytonite/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>36</td>
      <td>4</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>651191 rows × 29 columns</p>
</div>




```python
def ques(url):
    return url.count('?')
df['count_que'] = df['url'].apply(lambda i: ques(i))
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>google_index</th>
      <th>count-www</th>
      <th>count@</th>
      <th>count_dir</th>
      <th>count_embedded_dom</th>
      <th>is_short</th>
      <th>...</th>
      <th>fd_length</th>
      <th>tld</th>
      <th>tld_length</th>
      <th>type_code</th>
      <th>count_dot</th>
      <th>count_www</th>
      <th>count_atrate</th>
      <th>count_https</th>
      <th>count_per</th>
      <th>count_que</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>5</td>
      <td>None</td>
      <td>-1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>7</td>
      <td>None</td>
      <td>-1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>9</td>
      <td>be</td>
      <td>2</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>9</td>
      <td>net</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>651186</th>
      <td>xbox360.ign.com/objects/850/850402.html</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>7</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651187</th>
      <td>games.teamxbox.com/xbox-360/1860/Dead-Space/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>8</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651188</th>
      <td>www.gamespot.com/xbox360/action/deadspace/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>7</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651189</th>
      <td>en.wikipedia.org/wiki/Dead_Space_(video_game)</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>4</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651190</th>
      <td>www.angelfire.com/goth/devilmaycrytonite/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>4</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>651191 rows × 30 columns</p>
</div>




```python
df.head(20)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>google_index</th>
      <th>count.</th>
      <th>count-www</th>
      <th>count@</th>
      <th>count_dir</th>
      <th>count_embedded_dom</th>
      <th>is_short</th>
      <th>count-https</th>
      <th>count%</th>
      <th>count?</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>5</th>
      <td>http://buzzfil.net/m/show-art/ils-etaient-loin...</td>
      <td>benign</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>espn.go.com/nba/player/_/id/3457/brandon-rush</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>6</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>yourbittorrent.com/?q=anthony-hamilton-soulife</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>8</th>
      <td>http://www.pashminaonline.com/pure-pashminas</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>allmusic.com/album/crazy-from-the-heat-r16990</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>corporationwiki.com/Ohio/Columbus/frank-s-bens...</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>http://www.ikenmijnkunst.nl/index.php/expositi...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>12</th>
      <td>myspace.com/video/vid/30602581</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>13</th>
      <td>http://www.lebensmittel-ueberwachung.de/index....</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>14</th>
      <td>http://www.szabadmunkaero.hu/cimoldal.html?sta...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>15</th>
      <td>http://larcadelcarnevale.com/catalogo/palloncini</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>16</th>
      <td>quickfacts.census.gov/qfd/maps/iowa_map.html</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>17</th>
      <td>nugget.ca/ArticleDisplay.aspx?archive=true&amp;e=1...</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>18</th>
      <td>uk.linkedin.com/pub/steve-rubenstein/8/718/755</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>5</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>19</th>
      <td>http://www.vnic.co/khach-hang.html</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>google_index</th>
      <th>count.</th>
      <th>count-www</th>
      <th>count@</th>
      <th>count_dir</th>
      <th>count_embedded_dom</th>
      <th>is_short</th>
      <th>count-https</th>
      <th>count%</th>
      <th>count?</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>651186</th>
      <td>xbox360.ign.com/objects/850/850402.html</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651187</th>
      <td>games.teamxbox.com/xbox-360/1860/Dead-Space/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651188</th>
      <td>www.gamespot.com/xbox360/action/deadspace/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651189</th>
      <td>en.wikipedia.org/wiki/Dead_Space_(video_game)</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651190</th>
      <td>www.angelfire.com/goth/devilmaycrytonite/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>651191 rows × 14 columns</p>
</div>




```python
def dash(url):
    return url.count('-')
df['count_hyphen'] = df['url'].apply(lambda i: dash(i))
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>google_index</th>
      <th>count-www</th>
      <th>count@</th>
      <th>count_dir</th>
      <th>count_embedded_dom</th>
      <th>is_short</th>
      <th>...</th>
      <th>tld</th>
      <th>tld_length</th>
      <th>type_code</th>
      <th>count_dot</th>
      <th>count_www</th>
      <th>count_atrate</th>
      <th>count_https</th>
      <th>count_per</th>
      <th>count_que</th>
      <th>count_hyphen</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>None</td>
      <td>-1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>None</td>
      <td>-1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>be</td>
      <td>2</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>net</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>651186</th>
      <td>xbox360.ign.com/objects/850/850402.html</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651187</th>
      <td>games.teamxbox.com/xbox-360/1860/Dead-Space/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>651188</th>
      <td>www.gamespot.com/xbox360/action/deadspace/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651189</th>
      <td>en.wikipedia.org/wiki/Dead_Space_(video_game)</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651190</th>
      <td>www.angelfire.com/goth/devilmaycrytonite/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>None</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>651191 rows × 31 columns</p>
</div>




```python
def equal(url):
    return url.count('=')
df['count_equal'] = df['url'].apply(lambda i: equal(i))
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>google_index</th>
      <th>count-www</th>
      <th>count@</th>
      <th>count_dir</th>
      <th>count_embedded_dom</th>
      <th>is_short</th>
      <th>...</th>
      <th>tld_length</th>
      <th>type_code</th>
      <th>count_dot</th>
      <th>count_www</th>
      <th>count_atrate</th>
      <th>count_https</th>
      <th>count_per</th>
      <th>count_que</th>
      <th>count_hyphen</th>
      <th>count_equal</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>651186</th>
      <td>xbox360.ign.com/objects/850/850402.html</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>3</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651187</th>
      <td>games.teamxbox.com/xbox-360/1860/Dead-Space/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651188</th>
      <td>www.gamespot.com/xbox360/action/deadspace/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651189</th>
      <td>en.wikipedia.org/wiki/Dead_Space_(video_game)</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651190</th>
      <td>www.angelfire.com/goth/devilmaycrytonite/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>651191 rows × 32 columns</p>
</div>




```python
# function to find length of url
def url_length(url):
    return len(str(url))
df['url_length'] = df['url'].apply(lambda i: url_length(i))
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>google_index</th>
      <th>count-www</th>
      <th>count@</th>
      <th>count_dir</th>
      <th>count_embedded_dom</th>
      <th>is_short</th>
      <th>...</th>
      <th>tld_length</th>
      <th>type_code</th>
      <th>count_dot</th>
      <th>count_www</th>
      <th>count_atrate</th>
      <th>count_https</th>
      <th>count_per</th>
      <th>count_que</th>
      <th>count_hyphen</th>
      <th>count_equal</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>651186</th>
      <td>xbox360.ign.com/objects/850/850402.html</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>3</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651187</th>
      <td>games.teamxbox.com/xbox-360/1860/Dead-Space/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651188</th>
      <td>www.gamespot.com/xbox360/action/deadspace/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651189</th>
      <td>en.wikipedia.org/wiki/Dead_Space_(video_game)</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651190</th>
      <td>www.angelfire.com/goth/devilmaycrytonite/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>651191 rows × 32 columns</p>
</div>




```python
# finding length of hostname
def hname(url):
    l=len(urlparse(url).netloc)
    return l
df['hostname_length'] = df['url'].apply(lambda i: hname(i))
df
#netloc attribute represents the network location part of the URL, which typically includes the domain name and port(if given)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>google_index</th>
      <th>count-www</th>
      <th>count@</th>
      <th>count_dir</th>
      <th>count_embedded_dom</th>
      <th>is_short</th>
      <th>...</th>
      <th>tld_length</th>
      <th>type_code</th>
      <th>count_dot</th>
      <th>count_www</th>
      <th>count_atrate</th>
      <th>count_https</th>
      <th>count_per</th>
      <th>count_que</th>
      <th>count_hyphen</th>
      <th>count_equal</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>651186</th>
      <td>xbox360.ign.com/objects/850/850402.html</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>3</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651187</th>
      <td>games.teamxbox.com/xbox-360/1860/Dead-Space/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651188</th>
      <td>www.gamespot.com/xbox360/action/deadspace/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651189</th>
      <td>en.wikipedia.org/wiki/Dead_Space_(video_game)</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651190</th>
      <td>www.angelfire.com/goth/devilmaycrytonite/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>651191 rows × 32 columns</p>
</div>




```python
def suspicious_words(url):
    sw = re.search('PayPal|login|signin|bank|account|update|free|lucky|service|bonus|ebayisapi|webscr',url)
    # search for these suspicious words in the url
    if sw:
        return 1
    else:
        return 0
df['sus_url'] = df['url'].apply(lambda i: suspicious_words(i))
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>google_index</th>
      <th>count-www</th>
      <th>count@</th>
      <th>count_dir</th>
      <th>count_embedded_dom</th>
      <th>is_short</th>
      <th>...</th>
      <th>tld_length</th>
      <th>type_code</th>
      <th>count_dot</th>
      <th>count_www</th>
      <th>count_atrate</th>
      <th>count_https</th>
      <th>count_per</th>
      <th>count_que</th>
      <th>count_hyphen</th>
      <th>count_equal</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>651186</th>
      <td>xbox360.ign.com/objects/850/850402.html</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>3</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651187</th>
      <td>games.teamxbox.com/xbox-360/1860/Dead-Space/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651188</th>
      <td>www.gamespot.com/xbox360/action/deadspace/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651189</th>
      <td>en.wikipedia.org/wiki/Dead_Space_(video_game)</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651190</th>
      <td>www.angelfire.com/goth/devilmaycrytonite/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>-1</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>651191 rows × 32 columns</p>
</div>




```python
def dig(url):
    c = 0
    for i in url:
        if i.isnumeric():
            c=c+1
    return c
df['count_digits']= df['url'].apply(lambda i: dig(i))
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>google_index</th>
      <th>count-www</th>
      <th>count@</th>
      <th>count_dir</th>
      <th>count_embedded_dom</th>
      <th>is_short</th>
      <th>...</th>
      <th>type_code</th>
      <th>count_dot</th>
      <th>count_www</th>
      <th>count_atrate</th>
      <th>count_https</th>
      <th>count_per</th>
      <th>count_que</th>
      <th>count_hyphen</th>
      <th>count_equal</th>
      <th>count_digits</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
      <td>7</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>22</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>651186</th>
      <td>xbox360.ign.com/objects/850/850402.html</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>12</td>
    </tr>
    <tr>
      <th>651187</th>
      <td>games.teamxbox.com/xbox-360/1860/Dead-Space/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>7</td>
    </tr>
    <tr>
      <th>651188</th>
      <td>www.gamespot.com/xbox360/action/deadspace/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>651189</th>
      <td>en.wikipedia.org/wiki/Dead_Space_(video_game)</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>651190</th>
      <td>www.angelfire.com/goth/devilmaycrytonite/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>651191 rows × 33 columns</p>
</div>




```python
def let(url):
    l = 0
    for i in url:
        if i.isalpha():
            l= l + 1
    return l
df['count_letters']= df['url'].apply(lambda i: let(i))
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>google_index</th>
      <th>count-www</th>
      <th>count@</th>
      <th>count_dir</th>
      <th>count_embedded_dom</th>
      <th>is_short</th>
      <th>...</th>
      <th>count_dot</th>
      <th>count_www</th>
      <th>count_atrate</th>
      <th>count_https</th>
      <th>count_per</th>
      <th>count_que</th>
      <th>count_hyphen</th>
      <th>count_equal</th>
      <th>count_digits</th>
      <th>count_letters</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>13</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>29</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>25</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
      <td>7</td>
      <td>63</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>22</td>
      <td>199</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>651186</th>
      <td>xbox360.ign.com/objects/850/850402.html</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>12</td>
      <td>21</td>
    </tr>
    <tr>
      <th>651187</th>
      <td>games.teamxbox.com/xbox-360/1860/Dead-Space/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>7</td>
      <td>29</td>
    </tr>
    <tr>
      <th>651188</th>
      <td>www.gamespot.com/xbox360/action/deadspace/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>33</td>
    </tr>
    <tr>
      <th>651189</th>
      <td>en.wikipedia.org/wiki/Dead_Space_(video_game)</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>36</td>
    </tr>
    <tr>
      <th>651190</th>
      <td>www.angelfire.com/goth/devilmaycrytonite/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>36</td>
    </tr>
  </tbody>
</table>
<p>651191 rows × 34 columns</p>
</div>




```python
pip install tld
```

    Requirement already satisfied: tld in c:\users\dell\anaconda3\lib\site-packages (0.13)Note: you may need to restart the kernel to use updated packages.
    
    


```python
from urllib.parse import urlparse
from tld import get_tld
import os.path
```


```python
#First Directory Length
def fd_length(url):
    path= urlparse(url).path
    try:
        return len(path.split('/')[1])# before the first / is the first dir
    except:
        return 0
df['fd_length'] = df['url'].apply(lambda i: fd_length(i))
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>google_index</th>
      <th>count-www</th>
      <th>count@</th>
      <th>count_dir</th>
      <th>count_embedded_dom</th>
      <th>is_short</th>
      <th>...</th>
      <th>count_dot</th>
      <th>count_www</th>
      <th>count_atrate</th>
      <th>count_https</th>
      <th>count_per</th>
      <th>count_que</th>
      <th>count_hyphen</th>
      <th>count_equal</th>
      <th>count_digits</th>
      <th>count_letters</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>13</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>29</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>25</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
      <td>7</td>
      <td>63</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>22</td>
      <td>199</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>651186</th>
      <td>xbox360.ign.com/objects/850/850402.html</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>12</td>
      <td>21</td>
    </tr>
    <tr>
      <th>651187</th>
      <td>games.teamxbox.com/xbox-360/1860/Dead-Space/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>7</td>
      <td>29</td>
    </tr>
    <tr>
      <th>651188</th>
      <td>www.gamespot.com/xbox360/action/deadspace/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>33</td>
    </tr>
    <tr>
      <th>651189</th>
      <td>en.wikipedia.org/wiki/Dead_Space_(video_game)</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>36</td>
    </tr>
    <tr>
      <th>651190</th>
      <td>www.angelfire.com/goth/devilmaycrytonite/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>36</td>
    </tr>
  </tbody>
</table>
<p>651191 rows × 34 columns</p>
</div>




```python
df['tld'] = df['url'].apply(lambda i: get_tld(i,fail_silently=True))
def tld_length(tld):
    try:
        return len(tld)
    except:
        return -1
df['tld_length'] = df['tld'].apply(lambda i: tld_length(i))
# length pf top level domain
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>google_index</th>
      <th>count-www</th>
      <th>count@</th>
      <th>count_dir</th>
      <th>count_embedded_dom</th>
      <th>is_short</th>
      <th>...</th>
      <th>count_dot</th>
      <th>count_www</th>
      <th>count_atrate</th>
      <th>count_https</th>
      <th>count_per</th>
      <th>count_que</th>
      <th>count_hyphen</th>
      <th>count_equal</th>
      <th>count_digits</th>
      <th>count_letters</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>13</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>29</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>25</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
      <td>7</td>
      <td>63</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>22</td>
      <td>199</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>651186</th>
      <td>xbox360.ign.com/objects/850/850402.html</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>12</td>
      <td>21</td>
    </tr>
    <tr>
      <th>651187</th>
      <td>games.teamxbox.com/xbox-360/1860/Dead-Space/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>7</td>
      <td>29</td>
    </tr>
    <tr>
      <th>651188</th>
      <td>www.gamespot.com/xbox360/action/deadspace/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>33</td>
    </tr>
    <tr>
      <th>651189</th>
      <td>en.wikipedia.org/wiki/Dead_Space_(video_game)</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>36</td>
    </tr>
    <tr>
      <th>651190</th>
      <td>www.angelfire.com/goth/devilmaycrytonite/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>36</td>
    </tr>
  </tbody>
</table>
<p>651191 rows × 34 columns</p>
</div>




```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>google_index</th>
      <th>count-www</th>
      <th>count@</th>
      <th>count_dir</th>
      <th>count_embedded_dom</th>
      <th>is_short</th>
      <th>...</th>
      <th>count_dot</th>
      <th>count_www</th>
      <th>count_atrate</th>
      <th>count_https</th>
      <th>count_per</th>
      <th>count_que</th>
      <th>count_hyphen</th>
      <th>count_equal</th>
      <th>count_digits</th>
      <th>count_letters</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>13</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>29</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>25</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
      <td>7</td>
      <td>63</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>22</td>
      <td>199</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>651186</th>
      <td>xbox360.ign.com/objects/850/850402.html</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>12</td>
      <td>21</td>
    </tr>
    <tr>
      <th>651187</th>
      <td>games.teamxbox.com/xbox-360/1860/Dead-Space/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>7</td>
      <td>29</td>
    </tr>
    <tr>
      <th>651188</th>
      <td>www.gamespot.com/xbox360/action/deadspace/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>33</td>
    </tr>
    <tr>
      <th>651189</th>
      <td>en.wikipedia.org/wiki/Dead_Space_(video_game)</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>36</td>
    </tr>
    <tr>
      <th>651190</th>
      <td>www.angelfire.com/goth/devilmaycrytonite/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>36</td>
    </tr>
  </tbody>
</table>
<p>651191 rows × 34 columns</p>
</div>




```python
# label encoding
from sklearn.preprocessing import LabelEncoder
lb_make = LabelEncoder()
df["type_code"] = lb_make.fit_transform(df["type"])
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>type</th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>google_index</th>
      <th>count-www</th>
      <th>count@</th>
      <th>count_dir</th>
      <th>count_embedded_dom</th>
      <th>is_short</th>
      <th>...</th>
      <th>count_dot</th>
      <th>count_www</th>
      <th>count_atrate</th>
      <th>count_https</th>
      <th>count_per</th>
      <th>count_que</th>
      <th>count_hyphen</th>
      <th>count_equal</th>
      <th>count_digits</th>
      <th>count_letters</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>br-icloud.com.br</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>13</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mp3raid.com/music/krizz_kaliko.html</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>29</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bopsecrets.org/rexroth/cr/1.htm</td>
      <td>benign</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>25</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.garage-pirenne.be/index.php?option=...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
      <td>7</td>
      <td>63</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://adventure-nicaragua.net/index.php?optio...</td>
      <td>defacement</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>22</td>
      <td>199</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>651186</th>
      <td>xbox360.ign.com/objects/850/850402.html</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>12</td>
      <td>21</td>
    </tr>
    <tr>
      <th>651187</th>
      <td>games.teamxbox.com/xbox-360/1860/Dead-Space/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>7</td>
      <td>29</td>
    </tr>
    <tr>
      <th>651188</th>
      <td>www.gamespot.com/xbox360/action/deadspace/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>33</td>
    </tr>
    <tr>
      <th>651189</th>
      <td>en.wikipedia.org/wiki/Dead_Space_(video_game)</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>36</td>
    </tr>
    <tr>
      <th>651190</th>
      <td>www.angelfire.com/goth/devilmaycrytonite/</td>
      <td>phishing</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>36</td>
    </tr>
  </tbody>
</table>
<p>651191 rows × 34 columns</p>
</div>




```python
# segregating feature and target variables
#Predictor Variables
# filtering out google_index as it has only 1 value
x = df[['has_ip','abnormal_url', 'count_dot', 'count_www', 'count_atrate','count_dir', 'count_embedded_dom', 'is_short', 
        'count_https','count_per', 'count_que', 'count_hyphen', 'count_equal', 'url_length','hostname_length', 'sus_url', 'fd_length', 
        'tld_length', 'count_digits','count_letters']]
#Target Variable
y = df['type_code']
x
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>count_dot</th>
      <th>count_www</th>
      <th>count_atrate</th>
      <th>count_dir</th>
      <th>count_embedded_dom</th>
      <th>is_short</th>
      <th>count_https</th>
      <th>count_per</th>
      <th>count_que</th>
      <th>count_hyphen</th>
      <th>count_equal</th>
      <th>url_length</th>
      <th>hostname_length</th>
      <th>sus_url</th>
      <th>fd_length</th>
      <th>tld_length</th>
      <th>count_digits</th>
      <th>count_letters</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>16</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>-1</td>
      <td>0</td>
      <td>13</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>35</td>
      <td>0</td>
      <td>0</td>
      <td>5</td>
      <td>-1</td>
      <td>1</td>
      <td>29</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>31</td>
      <td>0</td>
      <td>0</td>
      <td>7</td>
      <td>-1</td>
      <td>1</td>
      <td>25</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
      <td>88</td>
      <td>21</td>
      <td>0</td>
      <td>9</td>
      <td>2</td>
      <td>7</td>
      <td>63</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>235</td>
      <td>23</td>
      <td>0</td>
      <td>9</td>
      <td>3</td>
      <td>22</td>
      <td>199</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>651186</th>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>39</td>
      <td>0</td>
      <td>0</td>
      <td>7</td>
      <td>-1</td>
      <td>12</td>
      <td>21</td>
    </tr>
    <tr>
      <th>651187</th>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>44</td>
      <td>0</td>
      <td>0</td>
      <td>8</td>
      <td>-1</td>
      <td>7</td>
      <td>29</td>
    </tr>
    <tr>
      <th>651188</th>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>42</td>
      <td>0</td>
      <td>0</td>
      <td>7</td>
      <td>-1</td>
      <td>3</td>
      <td>33</td>
    </tr>
    <tr>
      <th>651189</th>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>45</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>-1</td>
      <td>0</td>
      <td>36</td>
    </tr>
    <tr>
      <th>651190</th>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>41</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>-1</td>
      <td>0</td>
      <td>36</td>
    </tr>
  </tbody>
</table>
<p>651191 rows × 20 columns</p>
</div>




```python
# training and test split
# this dataset is imbalanced, ie. it contains certain percentages of benogn, phishing, malware etc urls while splitting 
# we need to take care that the splitting occurs evenly so we'll be using a satisfaction variable
x_train, x_test, y_train, y_test = train_test_split(x, y, stratify=y, test_size=0.2,shuffle=True, random_state=5)
```


```python
x_train
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>has_ip</th>
      <th>abnormal_url</th>
      <th>count_dot</th>
      <th>count_www</th>
      <th>count_atrate</th>
      <th>count_dir</th>
      <th>count_embedded_dom</th>
      <th>is_short</th>
      <th>count_https</th>
      <th>count_per</th>
      <th>count_que</th>
      <th>count_hyphen</th>
      <th>count_equal</th>
      <th>url_length</th>
      <th>hostname_length</th>
      <th>sus_url</th>
      <th>fd_length</th>
      <th>tld_length</th>
      <th>count_digits</th>
      <th>count_letters</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>209860</th>
      <td>0</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>36</td>
      <td>13</td>
      <td>0</td>
      <td>8</td>
      <td>3</td>
      <td>3</td>
      <td>24</td>
    </tr>
    <tr>
      <th>124821</th>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>26</td>
      <td>0</td>
      <td>0</td>
      <td>5</td>
      <td>-1</td>
      <td>7</td>
      <td>15</td>
    </tr>
    <tr>
      <th>539292</th>
      <td>1</td>
      <td>1</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>35</td>
      <td>21</td>
      <td>0</td>
      <td>6</td>
      <td>-1</td>
      <td>17</td>
      <td>9</td>
    </tr>
    <tr>
      <th>224836</th>
      <td>0</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>6</td>
      <td>4</td>
      <td>108</td>
      <td>19</td>
      <td>0</td>
      <td>9</td>
      <td>3</td>
      <td>19</td>
      <td>66</td>
    </tr>
    <tr>
      <th>161897</th>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>65</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>283</td>
      <td>11</td>
      <td>0</td>
      <td>4</td>
      <td>3</td>
      <td>82</td>
      <td>122</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>175524</th>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>28</td>
      <td>0</td>
      <td>0</td>
      <td>14</td>
      <td>-1</td>
      <td>0</td>
      <td>23</td>
    </tr>
    <tr>
      <th>82780</th>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>7</td>
      <td>0</td>
      <td>92</td>
      <td>13</td>
      <td>0</td>
      <td>20</td>
      <td>3</td>
      <td>0</td>
      <td>78</td>
    </tr>
    <tr>
      <th>7416</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>34</td>
      <td>0</td>
      <td>0</td>
      <td>5</td>
      <td>-1</td>
      <td>0</td>
      <td>30</td>
    </tr>
    <tr>
      <th>264781</th>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>48</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>-1</td>
      <td>0</td>
      <td>40</td>
    </tr>
    <tr>
      <th>305564</th>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>0</td>
      <td>0</td>
      <td>11</td>
      <td>-1</td>
      <td>0</td>
      <td>36</td>
    </tr>
  </tbody>
</table>
<p>520952 rows × 20 columns</p>
</div>




```python
from sklearn.ensemble import RandomForestClassifier
from sklearn import metrics

```


```python
# Random Forest Model
rf = RandomForestClassifier(n_estimators=100,max_features='sqrt')
rf.fit(x_train,y_train)
y_pred_rf = rf.predict(x_test)
print(classification_report(y_test,y_pred_rf,target_names=['benign', 'defacement','phishing','malware']))
score = metrics.accuracy_score(y_test, y_pred_rf)
print("accuracy:   %0.2f" % score)
```

    C:\Users\Dell\anaconda3\lib\site-packages\sklearn\utils\validation.py:623: FutureWarning: is_sparse is deprecated and will be removed in a future version. Check `isinstance(dtype, pd.SparseDtype)` instead.
      if not hasattr(array, "sparse") and array.dtypes.apply(is_sparse).any():
    C:\Users\Dell\anaconda3\lib\site-packages\sklearn\utils\validation.py:623: FutureWarning: is_sparse is deprecated and will be removed in a future version. Check `isinstance(dtype, pd.SparseDtype)` instead.
      if not hasattr(array, "sparse") and array.dtypes.apply(is_sparse).any():
    

                  precision    recall  f1-score   support
    
          benign       0.97      0.98      0.98     85621
      defacement       0.98      0.99      0.99     19292
        phishing       0.99      0.94      0.97      6504
         malware       0.91      0.86      0.88     18822
    
        accuracy                           0.97    130239
       macro avg       0.96      0.95      0.95    130239
    weighted avg       0.97      0.97      0.97    130239
    
    accuracy:   0.97
    


```python
xgb_c = xgb.XGBClassifier(n_estimators= 100)
xgb_c.fit(x_train,y_train)
y_pred_x = xgb_c.predict(x_test)
print(classification_report(y_test,y_pred_x,target_names=['benign', 'defacement','phishing','malware']))
score = metrics.accuracy_score(y_test, y_pred_x)
print("accuracy:   %0.2f" % score)
```

                  precision    recall  f1-score   support
    
          benign       0.97      0.99      0.98     85621
      defacement       0.97      0.99      0.98     19292
        phishing       0.97      0.92      0.94      6504
         malware       0.91      0.83      0.87     18822
    
        accuracy                           0.96    130239
       macro avg       0.96      0.93      0.94    130239
    weighted avg       0.96      0.96      0.96    130239
    
    accuracy:   0.96
    


```python
# Light GBM Classifier
lgb = LGBMClassifier(objective='multiclass',boosting_type= 'gbdt',n_jobs = 5, 
          silent = True, random_state=5)
LGB_C = lgb.fit(x_train, y_train)
y_pred_lgb = LGB_C.predict(x_test)
print(classification_report(y_test,y_pred_lgb,target_names=['benign', 'defacement','phishing','malware']))
score = metrics.accuracy_score(y_test, y_pred_lgb)
print("accuracy:   %0.2f" % score)
```

    [LightGBM] [Warning] Unknown parameter: silent
    [LightGBM] [Warning] Unknown parameter: silent
    [LightGBM] [Info] Auto-choosing row-wise multi-threading, the overhead of testing was 0.026286 seconds.
    You can set `force_row_wise=true` to remove the overhead.
    And if memory is not enough, you can set `force_col_wise=true`.
    [LightGBM] [Info] Total Bins 1152
    [LightGBM] [Info] Number of data points in the train set: 520952, number of used features: 20
    [LightGBM] [Info] Start training from score -0.419439
    [LightGBM] [Info] Start training from score -1.909712
    [LightGBM] [Info] Start training from score -2.996946
    [LightGBM] [Info] Start training from score -1.934324
    [LightGBM] [Warning] Unknown parameter: silent
                  precision    recall  f1-score   support
    
          benign       0.97      0.99      0.98     85621
      defacement       0.96      0.99      0.97     19292
        phishing       0.97      0.91      0.93      6504
         malware       0.90      0.82      0.86     18822
    
        accuracy                           0.96    130239
       macro avg       0.95      0.93      0.94    130239
    weighted avg       0.96      0.96      0.96    130239
    
    accuracy:   0.96
    


```python
# we'll select random forest classifier by virtue of highest accuracy

```


```python
feat_importances = pd.Series(rf.feature_importances_, index=x_train.columns)
feat_importances.sort_values().plot(kind="barh",figsize=(10, 6))
```




    <AxesSubplot:>




    
![png](output_59_1.png)
    



```python
def main(url):
    
    status = []
    
    status.append(has_ip(url))
    status.append(abnormal_url(url))
    status.append(count_dot(url))
    status.append(count_www(url))
    status.append(count_atrate(url))
    status.append(count_dir(url))
    status.append(count_embedded_dom(url))
    
    status.append(is_short(url))
    status.append(count_https(url))
    
    
    status.append(count_per(url))
    status.append(count_que(url))
    status.append(count_hyphen(url))
    status.append(count_equal(url))
    
    status.append(url_length(url))
    status.append(hostname_length(url))
    status.append(sus_url(url))
    status.append(count_digits(url))
    status.append(count_letters(url))
    status.append(fd_length(url))
    tld = get_tld(url,fail_silently=True)
      
    status.append(tld_length(tld))
    
    return status
def get_prediction_from_url(test_url):
    features_test = main(test_url)
    features_test = np.array(features_test).reshape((1, -1))
    pred = lgb.predict(features_test)
    if int(pred[0]) == 0:
        
        res="SAFE"
        return res
    elif int(pred[0]) == 1.0:
        
        res="DEFACEMENT"
        return res
    elif int(pred[0]) == 2.0:
        res="PHISHING"
        return res
        
    elif int(pred[0]) == 3.0:
        
        res="MALWARE"
        return res
urls = ['titaniumcorporate.co.za','en.wikipedia.org/wiki/North_Dakota']
for url in urls:
     print(get_prediction_from_url(url))
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    ~\AppData\Local\Temp\ipykernel_22668\3310964451.py in <module>
         53 urls = ['titaniumcorporate.co.za','en.wikipedia.org/wiki/North_Dakota']
         54 for url in urls:
    ---> 55      print(get_prediction_from_url(url))
    

    ~\AppData\Local\Temp\ipykernel_22668\3310964451.py in get_prediction_from_url(test_url)
         32     return status
         33 def get_prediction_from_url(test_url):
    ---> 34     features_test = main(test_url)
         35     features_test = np.array(features_test).reshape((1, -1))
         36     pred = lgb.predict(features_test)
    

    ~\AppData\Local\Temp\ipykernel_22668\3310964451.py in main(url)
          3     status = []
          4 
    ----> 5     status.append(has_ip(url))
          6     status.append(abnormal_url(url))
          7     status.append(count_dot(url))
    

    NameError: name 'has_ip' is not defined



```python
def get_prediction_from_url(test_url):
    features_test = main(test_url)
    features_test = np.array(features_test).reshape((1, -1))
    pred = lgb.predict(features_test)
    if int(pred[0]) == 0:
        
        res="SAFE"
        return res
    elif int(pred[0]) == 1.0:
        
        res="DEFACEMENT"
        return res
    elif int(pred[0]) == 2.0:
        res="PHISHING"
        return res
        
    elif int(pred[0]) == 3.0:
        
        res="MALWARE"
        return res
urls = ['titaniumcorporate.co.za','en.wikipedia.org/wiki/North_Dakota']
for url in urls:
     print(get_prediction_from_url(url))
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    ~\AppData\Local\Temp\ipykernel_22668\1470848316.py in <module>
         21 urls = ['titaniumcorporate.co.za','en.wikipedia.org/wiki/North_Dakota']
         22 for url in urls:
    ---> 23      print(get_prediction_from_url(url))
    

    ~\AppData\Local\Temp\ipykernel_22668\1470848316.py in get_prediction_from_url(test_url)
          1 def get_prediction_from_url(test_url):
    ----> 2     features_test = main(test_url)
          3     features_test = np.array(features_test).reshape((1, -1))
          4     pred = lgb.predict(features_test)
          5     if int(pred[0]) == 0:
    

    ~\AppData\Local\Temp\ipykernel_22668\1144193511.py in main(url)
          5     #status.append(has_ip(url))
          6     status.append(abnormal_url(url))
    ----> 7     status.append(count_dot(url))
          8     status.append(count_www(url))
          9     status.append(count_atrate(url))
    

    NameError: name 'count_dot' is not defined



```python

```
